USE CVGS;

GO

PRINT '>>> Creating Game Table';

CREATE TABLE Game
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Game_PK
     PRIMARY KEY CLUSTERED,
 Game_Name NVARCHAR(50) NOT NULL,
 Game_Image_URL NVARCHAR(50) NOT NULL,
 Game_Description NVARCHAR(200) NOT NULL,
 Price decimal(6,2) NOT NULL,
 Game_Overall_Rating INT
 ); 

GO

PRINT 'Create Game Table Finished';
PRINT '';