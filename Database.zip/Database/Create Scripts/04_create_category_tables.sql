USE CVGS;

GO

PRINT '>>> Creating Category Table';

CREATE TABLE Category
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Category_PK
     PRIMARY KEY CLUSTERED,
 CategoryName NVARCHAR(50) NOT NULL
 ); 

GO

PRINT '>>> Creating Category Prefernces Table';

CREATE TABLE Category_Preferneces
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Category_Preference_PK
     PRIMARY KEY CLUSTERED,
 UserId INT NOT NULL,
 CategoryId INT NOT NULL,
 FOREIGN KEY (UserId) REFERENCES [User](ID),
 FOREIGN KEY (CategoryId) REFERENCES Category(ID)
 ); 

GO


PRINT 'Create Category Tables Finished';
PRINT '';
