USE CVGS;

GO

PRINT '>>> Creating Review Table';

CREATE TABLE Review
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Review_PK
     PRIMARY KEY CLUSTERED,
 Review NVARCHAR(200) NOT NULL,
 Review_Date Date NOT NULL,
 Review_Status BIT NOT NULL,
 UserId INT NOT NULL,
 GameId INT NOT NULL,
 FOREIGN KEY (UserId) REFERENCES [User](ID),
 FOREIGN KEY (GameId) REFERENCES Game(ID)
 ); 

GO

PRINT 'Create Review Table Finished';
PRINT '';