 USE Reservationdb;

GO

PRINT '>>> Creating RestaurantDetails Table';

CREATE TABLE RestaurantDetails
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT RestaurantDetails_PK
     PRIMARY KEY CLUSTERED,
 Restaurant_Id INT NOT NULL,
 RestaurantLocation_Id INT NOT NULL,
 RestaurantTable_Id INT,
 RestaurantDay_Id INT,
 RestaurantTime_Id INT,
 RestaurantReview_Id INT,
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID),
 FOREIGN KEY (RestaurantLocation_Id) REFERENCES RestaurantLocation(ID),
 FOREIGN KEY (RestaurantTable_Id) REFERENCES RestaurantTable(ID),
 FOREIGN KEY (RestaurantDay_Id) REFERENCES RestaurantDay(ID),
 FOREIGN KEY (RestaurantTime_Id) REFERENCES RestaurantTime(ID),
 FOREIGN KEY (RestaurantReview_Id) REFERENCES RestaurantReview(ID)
 ); 

GO

PRINT 'Create RestaurantDetails Table Finished';
PRINT '';