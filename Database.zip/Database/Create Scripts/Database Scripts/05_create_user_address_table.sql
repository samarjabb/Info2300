 USE Reservationdb;

GO

PRINT '>>> Creating Address Table';

CREATE TABLE [Address]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Address_PK
     PRIMARY KEY CLUSTERED,
 User_Id INT NOT NULL,
 Street NVARCHAR(50),
 City NVARCHAR(50),
 Province_Id INT,
 Country_Id INT,
 Postal_Code NVARCHAR(50),
 FOREIGN KEY (User_Id) REFERENCES [User](ID),
 FOREIGN KEY (Province_Id) REFERENCES Province(ID),
 FOREIGN KEY (Country_Id) REFERENCES [Country](ID)
 ); 

GO

PRINT 'Create Address Table Finished';
PRINT '';