 USE Reservationdb;

GO

PRINT '>>> Creating Restaurant Table';

CREATE TABLE Restaurant
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Restaurant_PK
     PRIMARY KEY CLUSTERED,
 Restaurant_Name NVARCHAR(50)  NOT NULL,
 Restaurant_Description NVARCHAR(500),
 Restaurant_Phone INT
 ); 

GO

PRINT 'Create Restaurant Table Finished';
PRINT '';