USE Reservationdb;

GO

PRINT '>>> Creating Users Table';

CREATE TABLE [User]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT User_PK
     PRIMARY KEY CLUSTERED,
 Lastname NVARCHAR(50),
 Firstname NVARCHAR(50),
 Username NVARCHAR(50) NOT NULL,
 [Password] NVARCHAR(50) NOT NULL,
 Email NVARCHAR(100) NOT NULL,
 Birth_Date DATE
 );

GO

PRINT 'Create User Table Finished';
PRINT '';
