$Server = Read-Host -Prompt 'Input SQL server host'
$Dir = Read-Host -Prompt 'Input full path of create script directory'

Write-Host "Creating Reservationdb database in server '$Server'"

write-output "Creating database..."

SQLCMD -S $Server -i "$Dir\01_create_database.sql" -E

write-output "Creating User Table..."

SQLCMD -S $Server -i "$Dir\02_create_user_table.sql" -E

write-output "Creating Platform Tables..."

SQLCMD -S $Server -i "$Dir\03_create_platform_tables.sql" -E

write-output "Creating Category Tables..."

SQLCMD -S $Server -i "$Dir\04_create_category_tables.sql" -E

write-output "Creating Country Table..."

SQLCMD -S $Server -i "$Dir\05_create_country_table.sql" -E

write-output "Creating Province Table..."

SQLCMD -S $Server -i "$Dir\06_create_province_table.sql" -E

write-output "Creating Address Table..."

SQLCMD -S $Server -i "$Dir\07_create_address_table.sql" -E

write-output "Creating Game Table..."

SQLCMD -S $Server -i "$Dir\08_create_game_table.sql" -E

write-output "Creating Wish List Table..."

SQLCMD -S $Server -i "$Dir\09_create_wishlist_table.sql" -E

write-output "Creating Review Table..."

SQLCMD -S $Server -i "$Dir\10_create_review_table.sql" -E

write-output "Creating Credit Card Table..."

SQLCMD -S $Server -i "$Dir\11_create_creditCard_table.sql" -E

write-output "Creating Friend Table..."

SQLCMD -S $Server -i "$Dir\12_create_friend_table.sql" -E

write-output "Creating Event Tables..."

SQLCMD -S $Server -i "$Dir\13_create_event_tables.sql" -E


write-output "Creating Order Table..."

SQLCMD -S $Server -i "$Dir\14_create_order_table.sql" -E

write-output "Creating Reting Table..."

SQLCMD -S $Server -i "$Dir\15_create_rating_table.sql" -E

write-output "Inserting Data to Category Table..."

SQLCMD -S $Server -i "$Dir\Insert_Data_Category_Table.sql" -E

write-output "Inserting Data to Platform Table..."

SQLCMD -S $Server -i "$Dir\Insert_Data_Platform_Table.sql" -E

write-output "Inserting Data to Country Table..."

SQLCMD -S $Server -i "$Dir\Insert_Data_Country_Table.sql" -E

write-output "Inserting Data to Province Table..."

SQLCMD -S $Server -i "$Dir\Insert_Data_Province_Table.sql" -E