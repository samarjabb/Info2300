 USE Reservationdb;

GO

PRINT '>>> Creating ReservationStatus Table';

CREATE TABLE ReservationStatus
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT ReservationStatus_PK
     PRIMARY KEY CLUSTERED,
 Reservation_Id INT NOT NULL,
 Reservation_Status NVARCHAR(50),
 FOREIGN KEY (User_Id) REFERENCES [User](ID)
 ); 

GO

PRINT 'Create ReservationStatus Table Finished';
PRINT '';