 USE Reservationdb;

GO

PRINT '>>> Creating RestaurantTime Table';

CREATE TABLE RestaurantTime
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT RestaurantTime_PK
     PRIMARY KEY CLUSTERED,
 Restaurant_Id INT NOT NULL,
 Open_Time TIME,
 Close_Time TIME,
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID),
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID)
 ); 

GO

PRINT 'Create RestaurantTime Table Finished';
PRINT '';