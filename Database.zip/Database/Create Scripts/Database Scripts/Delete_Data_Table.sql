USE Reservationdb;

GO

DELETE FROM Address WHERE Id = 4;