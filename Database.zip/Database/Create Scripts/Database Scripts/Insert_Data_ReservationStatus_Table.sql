USE CVGS;

GO


INSERT INTO ReservationStatus
VALUES ('Yet to come');
INSERT INTO ReservationStatus
VALUES ('Done');

