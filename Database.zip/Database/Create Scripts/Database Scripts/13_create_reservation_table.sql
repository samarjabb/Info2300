 USE Reservationdb;

GO

PRINT '>>> Creating Reservation Table';

CREATE TABLE Reservation
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Reservation_PK
     PRIMARY KEY CLUSTERED,
 User_Id INT NOT NULL,
 Restaurant_Id INT NOT NULL,
 Guest_Number INT,
 Reservation_Date Date,
 Reservation_Time Time,
 ReservationStatus_Id INT,
 FOREIGN KEY (User_Id) REFERENCES [User](ID),
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID),
 FOREIGN KEY (ReservationStatus_Id) REFERENCES ReservationStatus(ID)
 ); 

GO

PRINT 'Create Reservation Table Finished';
PRINT '';