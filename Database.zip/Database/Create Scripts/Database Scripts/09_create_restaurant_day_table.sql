 USE Reservationdb;

GO

PRINT '>>> Creating RestaurantDay Table';

CREATE TABLE RestaurantDay
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT RestaurantDay_PK
     PRIMARY KEY CLUSTERED,
 Restaurant_Id INT NOT NULL,
 Week_Day NVARCHAR(50),
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID)
 ); 

GO

PRINT 'Create RestaurantDay Table Finished';
PRINT '';