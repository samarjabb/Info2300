USE CVGS;

GO


INSERT INTO [Country]
VALUES ('Canada');

