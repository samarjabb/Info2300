USE Reservationdb;

GO


DROP TABLE Country;