 USE Reservationdb;

GO

PRINT '>>> Creating RestaurantLocation Table';

CREATE TABLE RestaurantLocation
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT RestaurantLocation_PK
     PRIMARY KEY CLUSTERED,
 Restaurant_Id INT NOT NULL,
 Street NVARCHAR(50),
 City NVARCHAR(50),
 Province_Id INT,
 Country_Id INT,
 Postal_Code NVARCHAR(50),
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID),
 FOREIGN KEY (Province_Id) REFERENCES Province(ID),
 FOREIGN KEY (Country_Id) REFERENCES [Country](ID)
 ); 

GO

PRINT 'Create RestaurantLocation Table Finished';
PRINT '';