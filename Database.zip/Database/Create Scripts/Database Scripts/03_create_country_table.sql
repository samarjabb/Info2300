 USE Reservationdb;

GO

PRINT '>>> Creating Country Table';

CREATE TABLE [Country]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Country_PK
     PRIMARY KEY CLUSTERED,
 Country_Name NVARCHAR(50)  NOT NULL
 ); 

GO

PRINT 'Create Country Table Finished';
PRINT '';