USE CVGS;

GO

INSERT INTO Province
VALUES ('Alberta', 1);

INSERT INTO Province
VALUES ('British Columbia', 1);

INSERT INTO Province
VALUES ('Manitoba', 1);

INSERT INTO Province
VALUES ('New Brunswick', 1);

INSERT INTO Province
VALUES ('Newfoundland and Labrador', 1);

INSERT INTO Province
VALUES ('Northwest Territories', 1);

INSERT INTO Province
VALUES ('Nova Scotia', 1);

INSERT INTO Province
VALUES ('Nunavut', 1);

INSERT INTO Province
VALUES ('Ontario', 1);

INSERT INTO Province
VALUES ('Prince Edward Island', 1);

INSERT INTO Province
VALUES ('Quebec', 1);

INSERT INTO Province
VALUES ('Saskatchewan', 1);

INSERT INTO Province
VALUES ('Yukon', 1);