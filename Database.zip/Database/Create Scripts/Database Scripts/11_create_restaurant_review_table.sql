 USE Reservationdb;

GO

PRINT '>>> Creating RestaurantReview Table';

CREATE TABLE RestaurantReview
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT RestaurantReview_PK
     PRIMARY KEY CLUSTERED,
 Restaurant_Id INT NOT NULL,
 Review NVARCHAR(300),
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID)
 ); 

GO

PRINT 'Create RestaurantReview Table Finished';
PRINT '';