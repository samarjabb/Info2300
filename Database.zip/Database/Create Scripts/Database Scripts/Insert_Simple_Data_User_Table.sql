USE Reservationdb;

GO

INSERT INTO [User] 
VALUES ('Parkenson', 'Mary', 'mpark24', 'mp12345', 'ipatel@sentex.com', '1994-09-11');
