 USE Reservationdb;

GO

PRINT '>>> Creating RestaurantTable Table';

CREATE TABLE RestaurantTable
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT RestaurantTable_PK
     PRIMARY KEY CLUSTERED,
 Restaurant_Id INT NOT NULL,
 Seats INT,
 Quantity INT,
 FOREIGN KEY (Restaurant_Id) REFERENCES Restaurant(ID)
 ); 

GO

PRINT 'Create RestaurantTable Table Finished';
PRINT '';