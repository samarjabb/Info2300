 USE Reservationdb;

GO

PRINT '>>> Creating Province Table';

CREATE TABLE Province
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Province_PK
     PRIMARY KEY CLUSTERED,
 Province_Name NVARCHAR(50)  NOT NULL,
 Country_Id INT  NOT NULL
 FOREIGN KEY (CountryId) REFERENCES [Country](ID)
 ); 

GO

PRINT 'Create Province Table Finished';
PRINT '';