USE CVGS;

GO


INSERT INTO [Country]
VALUES ('Monday');
INSERT INTO [Country]
VALUES ('Tuesday');
INSERT INTO [Country]
VALUES ('Wednesday');
INSERT INTO [Country]
VALUES ('Thursday');
INSERT INTO [Country]
VALUES ('Friday');
INSERT INTO [Country]
VALUES ('Saturday');
INSERT INTO [Country]
VALUES ('Sunday');
