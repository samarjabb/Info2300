 USE CVGS;

GO

PRINT '>>> Creating Address Table';

CREATE TABLE [Address]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Address_PK
     PRIMARY KEY CLUSTERED,
 UserId INT NOT NULL,
 Street NVARCHAR(50),
 City NVARCHAR(50),
 ProvinceId INT,
 CountryId INT,
 PostalCode NVARCHAR(50),
 IsMailing_Address bit,
 Same_Address bit
 FOREIGN KEY (UserId) REFERENCES [User](ID),
 FOREIGN KEY (ProvinceId) REFERENCES Province(ID),
 FOREIGN KEY (CountryId) REFERENCES [Country](ID)
 ); 

GO

PRINT 'Create Address Table Finished';
PRINT '';