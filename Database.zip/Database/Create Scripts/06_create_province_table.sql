 USE CVGS;

GO

PRINT '>>> Creating Province Table';

CREATE TABLE Province
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Province_PK
     PRIMARY KEY CLUSTERED,
 ProvinceName NVARCHAR(50)  NOT NULL,
 CountryId INT  NOT NULL
 FOREIGN KEY (CountryId) REFERENCES [Country](ID)
 ); 

GO

PRINT 'Create Province Table Finished';
PRINT '';