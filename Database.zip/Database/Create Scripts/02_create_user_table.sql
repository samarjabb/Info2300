USE CVGS;

GO

PRINT '>>> Creating Users Table';

CREATE TABLE [User]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT User_PK
     PRIMARY KEY CLUSTERED,
 Lastname NVARCHAR(50),
 Firstname NVARCHAR(50),
 Username NVARCHAR(50) NOT NULL,
 [Password] NVARCHAR(50) NOT NULL,
 Email NVARCHAR(100) NOT NULL,
 GetEmail BIT,
 Gender NVARCHAR(100),
 Birthdate DATE,
 UserType VARCHAR(20) NOT NULL
 );

GO

PRINT 'Create User Table Finished';
PRINT '';
