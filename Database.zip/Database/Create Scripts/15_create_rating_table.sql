PRINT '>>> Creating Rating Table';

CREATE TABLE Rating
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Rating_PK
     PRIMARY KEY CLUSTERED,
 Rating_Text NVARCHAR(200) NOT NULL,
 GameId INT NOT NULL,
 UserId INT NOT NULL,
 FOREIGN KEY (GameId) REFERENCES [Game](ID),
 FOREIGN KEY (UserId) REFERENCES [User](ID)
 ); 

GO


PRINT 'Create Rating Tables Finished';
PRINT '';