USE CVGS;

GO

PRINT '>>> Creating Platform Table';

CREATE TABLE [Platform]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Platform_PK
     PRIMARY KEY CLUSTERED,
 PlatformName NVARCHAR(50) NOT NULL
 ); 

GO

PRINT '>>> Creating Platform Prefernces Table';

CREATE TABLE Platform_Preferneces
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Platform_Preference_PK
     PRIMARY KEY CLUSTERED,
 UserId INT NOT NULL,
 PlatformId INT NOT NULL,
 FOREIGN KEY (UserId) REFERENCES [User](ID),
 FOREIGN KEY (PlatformId) REFERENCES Platform(ID)
 ); 

GO


PRINT 'Create Platform Tables Finished';
PRINT '';

