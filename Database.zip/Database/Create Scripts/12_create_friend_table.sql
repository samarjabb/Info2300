USE CVGS;

GO

PRINT '>>> Creating Friend Table';

CREATE TABLE Friend
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Friend_PK
     PRIMARY KEY CLUSTERED,
 UserId INT NOT NULL,
 FriendId INT NOT NULL,
 FOREIGN KEY (UserId) REFERENCES [User](ID),
 FOREIGN KEY (UserId) REFERENCES [User](ID)
 ); 

GO

PRINT 'Create Friend Table Finished';
PRINT '';