 USE CVGS;

GO

PRINT '>>> Creating Country Table';

CREATE TABLE [Country]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Country_PK
     PRIMARY KEY CLUSTERED,
 CountryName NVARCHAR(50)  NOT NULL
 ); 

GO

PRINT 'Create Country Table Finished';
PRINT '';