USE CVGS;

GO


INSERT INTO Platform_Preferneces
VALUES (1, 6);
