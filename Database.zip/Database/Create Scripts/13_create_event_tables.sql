USE CVGS;

GO

PRINT '>>> Creating Event Table';

CREATE TABLE [Event]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Event_PK
     PRIMARY KEY CLUSTERED,
 Event_Name NVARCHAR(50) NOT NULL,
 Event_Image_URL NVARCHAR(50) NOT NULL,
 Event_Description NVARCHAR(50) NOT NULL,
 Event_Date Date NOT NULL,
 ); 

GO

PRINT '>>> Creating Event Registration Table';

CREATE TABLE Event_Registration
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Event_Registration_PK
     PRIMARY KEY CLUSTERED,
 EventId INT NOT NULL,
 UserId INT NOT NULL,
 FOREIGN KEY (EventId) REFERENCES [Event](ID),
 FOREIGN KEY (UserId) REFERENCES [User](ID)
 ); 

GO


PRINT 'Create Event Registration Tables Finished';
PRINT '';