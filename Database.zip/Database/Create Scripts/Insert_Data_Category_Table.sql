USE CVGS;

GO


INSERT INTO Category
VALUES ('Action');

INSERT INTO Category
VALUES ('Fighting');

INSERT INTO Category
VALUES ('Music and Party');

INSERT INTO Category
VALUES ('Puzzle');

INSERT INTO Category
VALUES ('RPG');

INSERT INTO Category
VALUES ('Shooter');

INSERT INTO Category
VALUES ('Simulation');

INSERT INTO Category
VALUES ('Sports');

INSERT INTO Category
VALUES ('Strategy');

