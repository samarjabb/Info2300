USE CVGS;

GO

PRINT '>>> Creating Credit Card Table';

CREATE TABLE Credit_Card
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Credit_Card_PK
     PRIMARY KEY CLUSTERED,
 Card_Number INT NOT NULL,
 Card_Holder_Name NVARCHAR(50) NOT NULL,
 CVC INT NOT NULL,
 UserId INT NOT NULL,
 GameId INT NOT NULL,
 FOREIGN KEY (UserId) REFERENCES [User](ID),
 FOREIGN KEY (GameId) REFERENCES Game(ID)
 ); 

GO

PRINT 'Create Credit Card Table Finished';
PRINT '';