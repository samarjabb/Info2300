USE CVGS;

GO

PRINT '>>> Creating Order Table';

CREATE TABLE [Order]
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Order_PK
     PRIMARY KEY CLUSTERED,
 Order_Date Date NOT NULL,
 TotalAmount INT NOT NULL,
 Order_status BIT NOT NULL,
 Credit_CardId INT NOT NULL,
 UserId INT NOT NULL,
 FOREIGN KEY (Credit_CardId) REFERENCES Credit_Card(ID),
 FOREIGN KEY (UserId) REFERENCES [User](ID)
 ); 

GO

PRINT '>>> Creating Order Detail Table';

CREATE TABLE Order_Detail
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Order_Detail_PK
     PRIMARY KEY CLUSTERED,
 OrderId INT NOT NULL,
 GameId INT NOT NULL,
 FOREIGN KEY (OrderId) REFERENCES [Order](ID),
 FOREIGN KEY (GameId) REFERENCES Game(ID)
 ); 

GO


PRINT 'Create Order Detail Tables Finished';
PRINT '';