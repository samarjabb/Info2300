USE CVGS;

GO

INSERT INTO [User] 
VALUES ('Parkenson', 'Mary', 'mpark24', 'mp12345', 'ipatel@sentex.com', 'true', 'Female', '1994-09-11', 'Member');
