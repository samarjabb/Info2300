USE CVGS;

GO

PRINT '>>> Creating Wishlist Table';

CREATE TABLE Wishlist
(
 Id INT NOT NULL IDENTITY
     CONSTRAINT Wishlist_PK
     PRIMARY KEY CLUSTERED,
 UserId INT NOT NULL,
 GameId INT NOT NULL,
 FOREIGN KEY (UserId) REFERENCES [User](ID),
 FOREIGN KEY (GameId) REFERENCES Game(ID)
 ); 

GO

PRINT 'Create Wishlist Table Finished';
PRINT '';