USE CVGS;

GO


INSERT INTO [Platform]
VALUES ('Nintentdo DS');

INSERT INTO [Platform]
VALUES ('Personal Computer Games');

INSERT INTO [Platform]
VALUES ('Sony PlayStation 1');

INSERT INTO [Platform]
VALUES ('Sony PlayStation 2');

INSERT INTO [Platform]
VALUES ('Sony PlayStation 3');

INSERT INTO [Platform]
VALUES ('Sony PlayStation Portable');

INSERT INTO [Platform]
VALUES ('Super Nintentdo Entertainment System');

INSERT INTO [Platform]
VALUES ('Nintentdo Wii');

INSERT INTO [Platform]
VALUES ('Microsoft XBox 360');

